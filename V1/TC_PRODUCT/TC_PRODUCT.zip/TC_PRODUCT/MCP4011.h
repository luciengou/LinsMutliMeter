#ifndef __MCP4011_H_
#define __MCP4011_H_

void Decrement_R(unsigned char value_up);         // up
void Increment_R(unsigned char value_down);	 //down

#endif