#ifndef __SOUND_H_
#define __SOUND_H_

void PlaySound(unsigned char  Num);// Play Sound;

#endif