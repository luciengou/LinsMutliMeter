#include <MPC82G516.h>
#include <Sound.h>

void S_Delay(unsigned int n)  ;
