/************************************************************************
* FileName     : i2c.h
* Description  : Default MPC82G516 to ctrl AD111A0 IC function.
*
*
* Version control:
***************************************************************************/
#ifndef __DAC6571_mA_H__
#define __DAC6571_mA_H__


void DAC6571mA_Init(void);
void DAC6571mA_start(void);
void DAC6571mA_stop(void);
void DAC6571mA_write_byte(unsigned char bt);
void mA_Delay(unsigned int n);
void Set_mA(unsigned int mA_Value);

#define         TRUE	1
#define         FALSE   0

#endif 